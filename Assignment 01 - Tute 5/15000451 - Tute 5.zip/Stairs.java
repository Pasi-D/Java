/* This is not the final java file. 
Please compile all java files first and run newStairs.java using 
java newStairs command in cli */

class Stairs extends newStars{
	public static void main(String[] args) {
		createStairs();
	}

	static void createStairs(){
		makeStars("                                    ");
		makeStars("                           ");
		makeStars("                  ");
		makeStars("         ");
		makeStars("");
	}

}